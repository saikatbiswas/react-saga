Complete code example app for the Udemy Redux Saga course: https://www.udemy.com/course/redux-saga/?referralCode=4C70801F898304D0A9FC
